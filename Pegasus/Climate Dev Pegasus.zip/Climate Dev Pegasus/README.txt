Climate Dev Pegasus
====================================

Alpha Release Install Information
------------------------------------

This Alpha release does not have a dedicated installer.
To properly run the software, follow the following
process:

-Unzip the contents of the program zip file
-Move the main directory to your home drive (C:\Users\user)
-Go to path C:\Users\user\Climate Dev Pegasus\Scheduler
-Run scheduler.bat as an administrator

To stop data collection:

-Go to path C:\Users\user\Climate Dev Pegasus\Scheduler
-Run stop.bat as an administrator

All output data files are stored at this path:
C:\Users\user\Climate Dev Pegasus\Data

As of this Alpha release, data will look as follows:
Date	        Opening Price	Closing Price
21/04/2020	23,141.15	#Empty
21/04/2020	#Empty	        23,129.24
22/04/2020	23,102.43	#Empty
22/04/2020	#Empty	        23,115.09

Please report any and all bugs with this software to https://climatedev.com/contact-us

